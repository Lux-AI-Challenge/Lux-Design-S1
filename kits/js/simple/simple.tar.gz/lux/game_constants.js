/**
 * All game constants
 */
const GAME_CONSTANTS = require('./game_constants.json');

module.exports = GAME_CONSTANTS;