#!/bin/bash

emcc --std=c++17 -s FORCE_FILESYSTEM=1 --pre-js internals/init_fs.js main.cpp -o main.js
