package lux;

public class Resource {
  public String type;
  public int amount;
  Resource(String type, int amt) {
    this.type = type;
    this.amount = amt;
  }
}
