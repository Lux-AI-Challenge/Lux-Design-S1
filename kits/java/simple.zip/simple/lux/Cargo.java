package lux;

public class Cargo {
  public int wood;
  public int coal;
  public int uranium;
  public Cargo(int wood, int coal, int uranium) {
    this.wood = wood;
    this.coal = coal;
    this.uranium = uranium;
  }
}
